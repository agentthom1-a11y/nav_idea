import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import http from "http";
import { Server as SocketIOServer } from "socket.io";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

async function startServer() {
  const app = express();
  const PORT = 3000;
  const httpServer = http.createServer(app);
  const io = new SocketIOServer(httpServer, {
    cors: { origin: '*' }
  });

  const activeUsers = new Map();

  io.on("connection", (socket) => {
    let currentRoom = null;
    let currentUser = null;

    socket.on("join-document", ({ documentId, user }) => {
      if (currentRoom) {
        socket.leave(currentRoom);
        const prevRoomUsers = activeUsers.get(currentRoom);
        if (prevRoomUsers) {
          prevRoomUsers.delete(socket.id);
          io.to(currentRoom).emit("presence-update", Array.from(prevRoomUsers.values()));
        }
      }

      currentRoom = `doc_${documentId}`;
      currentUser = user;
      socket.join(currentRoom);

      if (!activeUsers.has(currentRoom)) {
        activeUsers.set(currentRoom, new Map());
      }
      const roomUsers = activeUsers.get(currentRoom);
      roomUsers.set(socket.id, user);

      io.to(currentRoom).emit("presence-update", Array.from(roomUsers.values()));
    });

    socket.on("disconnect", () => {
      if (currentRoom && activeUsers.has(currentRoom)) {
        const roomUsers = activeUsers.get(currentRoom);
        roomUsers.delete(socket.id);
        io.to(currentRoom).emit("presence-update", Array.from(roomUsers.values()));
        if (roomUsers.size === 0) {
          activeUsers.delete(currentRoom);
        }
      }
    });
  });

  app.use(express.json());

const buildContextString = (brandContext: any) => {
  if (!brandContext) return '';
  const { brandName, targetAudience, brandVoice, competitors, additionalContext } = brandContext;
  if (!brandName && !targetAudience && !brandVoice && !competitors && !additionalContext) return '';
  
  let ctx = '\n\n--- BRAND CONTEXT ---\n';
  if (brandName) ctx += `Brand Name: ${brandName}\n`;
  if (targetAudience) ctx += `Target Audience: ${targetAudience}\n`;
  if (brandVoice) ctx += `Brand Voice/Tone: ${brandVoice}\n`;
  if (competitors) ctx += `Competitors: ${competitors}\n`;
  if (additionalContext) ctx += `Additional Context: ${additionalContext}\n`;
  ctx += '---------------------\n\nPlease ensure all generated content aligns strictly with the Brand Context provided above.';
  return ctx;
};


  app.post("/api/generate-content", async (req, res) => {
    try {
      const { platform, pillar, topic, brandContext } = req.body;
      
      const prompt = `You are an expert social media manager. Generate a highly engaging social media post for ${platform}.
Topic/Pillar: ${pillar || topic || 'General industry trends'}
Requirements:
- Research current trends and news on this topic.
- Match the tone and format expected on ${platform}.
- Include relevant hashtags.
- Suggest an image or video concept if applicable.
- Make it actionable and engaging.
- Output ONLY the post content, no extra markdown or pleasantries.` + buildContextString(brandContext);

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
        }
      });

      res.json({ content: response.text });
    } catch (error: any) {
      console.error("Gemini API error:", error);
      res.status(500).json({ error: error.message || "Failed to generate content" });
    }
  });

  app.post("/api/generate-weekly-plan", async (req, res) => {
    try {
      const { platforms, topics, startDate, brandContext } = req.body;
      
      const prompt = `You are an expert social media manager. Create a 7-day content plan starting from ${startDate} for the following platforms: ${platforms.join(', ')}.
Focus on these topics/pillars: ${topics.join(', ')}.
First, search for current events and trending topics in these areas to make the content relevant.

Respond ONLY with a valid JSON array of objects representing the content items. Do not include markdown code blocks like \`\`\`json.
Each object must have the following exact schema:
{
  "title": "A short catchy title for internal use",
  "platform": "The exact platform name (e.g. Instagram, TikTok, LinkedIn, X, Facebook)",
  "contentType": "Post, Video, Reel, Shorts, Article, Carousel, Story",
  "publishAt": "ISO date string for the publishing date",
  "caption": "The full post text, including hashtags and structure appropriate for the platform"
}` + buildContextString(brandContext);

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
        }
      });

      const plan = JSON.parse(response.text || "[]");
      res.json({ plan });
    } catch (error: any) {
      console.error("Gemini API error:", error);
      res.status(500).json({ error: error.message || "Failed to generate plan" });
    }
  });

  app.post("/api/generate-daily-suggestions", async (req, res) => {
    try {
      const { platforms, topics, date, brandContext } = req.body;
      
      const prompt = `You are an expert social media manager. Create daily content suggestions for ${date || "today"} for the following platforms: ${platforms.join(", ")}.
Focus on these topics/pillars: ${topics.join(", ")}.
Research current trending news for these topics today to provide hyper-relevant suggestions.

Respond ONLY with a valid JSON array of objects representing the suggested posts. Do not include markdown code blocks like \`\`\`json.
Each object must have the following exact schema:
{
  "title": "A short catchy title for internal use",
  "platform": "The exact platform name (e.g. Instagram, TikTok, LinkedIn, X, Facebook)",
  "contentType": "Post, Video, Reel, Shorts, Article, Carousel, Story",
  "publishAt": "ISO date string for the publishing date",
  "caption": "The full post text, including hashtags and structure appropriate for the platform"
}` + buildContextString(brandContext);

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
        }
      });

      const suggestions = JSON.parse(response.text || "[]");
      res.json({ suggestions });
    } catch (error: any) {
      console.error("Gemini API error:", error);
      res.status(500).json({ error: error.message || "Failed to generate daily suggestions" });
    }
  });


  
  app.post("/api/generate-all-details", async (req, res) => {
    try {
      const { topic, platform, contentType, brandContext } = req.body;
      
      const prompt = `You are an expert social media manager and content creator.
The user wants to generate a complete content plan based on the following topic or rough idea: "${topic}".
Target Platform: ${platform || "Any appropriate platform"}
Content Type: ${contentType || "Any appropriate format"}

Requirements:
1. Search the web for current news, trends, and accurate information related to this topic.
2. Ensure all generated data is valid, factual, and highly engaging.
3. Generate a complete set of details for this content piece.

Respond ONLY with a valid JSON object representing the generated content details. Do not include markdown code blocks like \`\`\`json.
The JSON object must have this exact schema:
{
  "title": "A catchy, optimized title for internal tracking and the post itself",
  "description": "A detailed content brief (what the content is about, key points, goals, call to action)",
  "script": "A detailed script or outline if it's a video/audio, or a longer format body structure",
  "caption": "The actual post caption optimized for the platform, including emojis and hashtags"
}` + buildContextString(brandContext);

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
        }
      });

      const details = JSON.parse(response.text || "{}");
      res.json({ details });
    } catch (error) {
      console.error("Gemini API error (Generate All):", error);
      res.status(500).json({ error: error.message || "Failed to generate all details" });
    }
  });

  app.post("/api/seo-audit", async (req, res) => {
    try {
      const { text, keywords, platform, brandContext } = req.body;
      
      const prompt = `You are an expert SEO and Content Analyst. Analyze the following content for SEO and readability.
Content: "${text}"
Target Keywords: ${keywords || "None provided"}
Target Platform: ${platform}

Provide your analysis in JSON format exactly matching this schema:
{
  "score": number (0-100 overall SEO/Content score),
  "readabilityScore": number (0-100 readability score),
  "keywordAnalysis": "Brief analysis of how well the keywords are utilized",
  "readabilityFeedback": "Brief feedback on reading level, tone, and pacing",
  "suggestions": ["suggestion 1", "suggestion 2", "suggestion 3"]
}` + buildContextString(brandContext);

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        }
      });

      const analysis = JSON.parse(response.text || "{}");
      res.json(analysis);
    } catch (error) {
      console.error("Gemini API error (SEO Audit):", error);
      res.status(500).json({ error: error.message || "Failed to analyze content" });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
