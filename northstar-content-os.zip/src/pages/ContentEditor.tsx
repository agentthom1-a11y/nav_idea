import { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { ContentItem, Status } from '../types';
import { PLATFORM_COLORS, STATUS_COLORS, cn, formatFriendlyDate, generateId, formatTimeAgo } from '../lib/utils';
import { ArrowLeft, Save, MessageSquare, MoreHorizontal, CheckCircle2, AlertCircle, Play, LayoutGrid, Sparkles, Loader2, Activity, Target } from 'lucide-react';
import { aiService, SeoAnalysis } from '../services/ai';
import { io } from 'socket.io-client';
import { User } from '../types';
import { Card, CardContent } from '../components/ui/card';
import { ReadabilityRing } from '../components/ReadabilityRing';

const TABS = ['Overview', 'Brief', 'Script', 'Assets', 'Caption', 'Review', 'SEO'];

export default function ContentEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { content, updateContent, addContent, currentUser, brandContext } = useStore();
  
  const isNew = id === 'new';
  const existingItem = content.find(c => c.id === id);
  
  const [activeTab, setActiveTab] = useState('Overview');
  const [item, setItem] = useState<Partial<ContentItem>>(
    existingItem || {
      title: '',
      platform: 'Instagram',
      contentType: 'Reel',
      status: 'DRAFT',
      priority: 'MEDIUM',
      ownerId: currentUser.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  );

  const [isGenerating, setIsGenerating] = useState(false);
  const [isAuditing, setIsAuditing] = useState(false);
  const [seoKeywords, setSeoKeywords] = useState('');
  const [seoAnalysis, setSeoAnalysis] = useState<SeoAnalysis | null>(null);

  const [activeCollaborators, setActiveCollaborators] = useState<User[]>([]);

  const realTimeSeo = useMemo(() => {
    const text = ((item.script || '') + ' ' + (item.caption || '')).trim();
    if (!text) return { readability: 0, words: 0, sentences: 0, keywords: [] };
    
    const words = text.split(/\s+/).filter(w => w.length > 0);
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    
    let syllables = 0;
    words.forEach(word => {
      const wordLower = word.toLowerCase();
      const match = wordLower.match(/[aeiouy]{1,2}/g);
      let count = match ? match.length : 1;
      if (wordLower.endsWith('e') && count > 1) count--;
      syllables += count;
    });

    const wps = sentences.length ? words.length / sentences.length : 0;
    const spw = words.length ? syllables / words.length : 0;
    const readabilityScore = Math.max(0, Math.min(100, Math.round(206.835 - (1.015 * wps) - (84.6 * spw))));

    let keywordDensities = [];
    if (seoKeywords) {
      const targetKeys = seoKeywords.split(',').map(k => k.trim().toLowerCase()).filter(k => k.length > 0);
      const textLower = text.toLowerCase();
      keywordDensities = targetKeys.map(kw => {
        const count = (textLower.match(new RegExp('\\b' + kw.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\  const [activeCollaborators, setActiveCollaborators] = useState<User[]>([]);') + '\\b', 'g')) || []).length;
        const density = words.length ? ((count / words.length) * 100).toFixed(1) : '0.0';
        return { keyword: kw, count, density: parseFloat(density) };
      });
    }

    return { readability: readabilityScore, words: words.length, sentences: sentences.length, keywords: keywordDensities };
  }, [item.script, item.caption, seoKeywords]);


  useEffect(() => {
    if (!id || id === 'new') return;

    const socket = io();

    socket.on('connect', () => {
      socket.emit('join-document', { documentId: id, user: currentUser });
    });

    socket.on('presence-update', (users: User[]) => {
      // Create a unique list based on user ID and filter out self
      const uniqueUsers = Array.from(new Map(users.map(u => [u.id, u])).values());
      setActiveCollaborators(uniqueUsers.filter(u => u.id !== currentUser.id));
    });

    return () => {
      socket.disconnect();
    };
  }, [id, currentUser]);


  const handleSeoAudit = async () => {
    const textToAnalyze = item.script || item.caption;
    if (!textToAnalyze) {
      alert("Please provide some script or caption content first.");
      return;
    }
    setIsAuditing(true);
    try {
      const result = await aiService.auditSEO(textToAnalyze, seoKeywords, item.platform || 'General');
      setSeoAnalysis(result);
    } catch (error) {
      console.error("Failed to run SEO audit", error);
      alert("Failed to run SEO audit. Please try again.");
    } finally {
      setIsAuditing(false);
    }
  };


  const handleSave = () => {
    if (isNew) {
      const newItem = { ...item, id: generateId() } as ContentItem;
      addContent(newItem);
      navigate(`/content/${newItem.id}`, { replace: true });
    } else {
      updateContent(item.id as string, { ...item, updatedAt: new Date().toISOString() });
    }
  };

  const handleStatusChange = (status: Status) => {
    setItem({ ...item, status });
  };


  const generateAllWithAI = async () => {
    if (!item.title && !item.description) {
      alert("Please provide at least a rough topic, title, or idea in the Title or Overview description.");
      return;
    }
    
    setIsGenerating(true);
    try {
      const response = await fetch('/api/generate-all-details', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          platform: item.platform,
          contentType: item.contentType,
          topic: `${item.title || ''} ${item.description || ''}`,
          brandContext
        })
      });
      const data = await response.json();
      if (data.details) {
        setItem(prev => ({ 
          ...prev, 
          title: data.details.title || prev.title,
          description: data.details.description || prev.description,
          script: data.details.script || prev.script,
          caption: data.details.caption || prev.caption
        }));
        alert("Successfully generated complete content details and researched trends!");
      }
    } catch (error) {
      console.error("Failed to generate all details", error);
      alert("Failed to generate details. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const generateWithAI = async (field: 'script' | 'caption') => {
    if (!item.title && !item.description) {
      alert("Please provide a title or description first.");
      return;
    }
    
    setIsGenerating(true);
    try {
      const response = await fetch('/api/generate-content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          platform: item.platform,
          topic: item.title,
          pillar: item.description,
          brandContext
        })
      });
      const data = await response.json();
      if (data.content) {
        setItem(prev => ({ ...prev, [field]: data.content }));
      }
    } catch (error) {
      console.error("Failed to generate content", error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-hidden bg-white dark:bg-slate-950">
      {/* Header */}
      <header className="h-16 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between px-6 shrink-0 bg-white dark:bg-slate-950 z-10">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => navigate('/content')}
            className="p-1.5 rounded-md text-slate-400 hover:text-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 dark:hover:text-white transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          
          <div className="flex items-center gap-3">
            <span className={cn("text-xs font-bold px-2 py-1 rounded-md uppercase tracking-wider", PLATFORM_COLORS[item.platform || 'Instagram'])}>
              {item.platform} {item.contentType}
            </span>
            <input 
              type="text" 
              value={item.title || ''}
              onChange={(e) => setItem({...item, title: e.target.value})}
              placeholder="Content Title..."
              className="font-bold text-xl bg-transparent outline-none border-none focus:ring-0 w-64 md:w-96 placeholder:text-slate-300 dark:placeholder:text-slate-700 text-slate-900 dark:text-white"
            />
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          {activeCollaborators.length > 0 && (
            <div className="flex items-center -space-x-2 mr-2">
              {activeCollaborators.map(collaborator => (
                <div 
                  key={collaborator.id} 
                  className="w-8 h-8 rounded-full bg-indigo-100 border-2 border-white dark:border-slate-950 flex items-center justify-center text-indigo-700 font-bold text-xs relative group z-20"
                >
                  {collaborator.avatar ? (
                    <img src={collaborator.avatar} alt={collaborator.name} className="w-full h-full rounded-full" />
                  ) : (
                    collaborator.name.charAt(0)
                  )}
                  <div className="absolute top-10 right-0 bg-slate-900 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 whitespace-nowrap pointer-events-none transition-opacity z-50">
                    {collaborator.name} is here
                  </div>
                </div>
              ))}
            </div>
          )}
          <div className="text-sm text-slate-500 hidden sm:block">
            {isNew ? 'Not saved' : `Saved ${formatTimeAgo(item.updatedAt || new Date().toISOString())}`}
          </div>
          <button 
            onClick={generateAllWithAI}
            disabled={isGenerating}
            className="flex items-center gap-2 bg-blue-600/10 text-blue-600 dark:bg-blue-500/20 dark:text-blue-400 px-3 py-2 rounded-md font-medium hover:bg-blue-600/20 transition-colors border border-blue-600/20 shadow-sm"
            title="Auto-generate complete content details and brief based on title"
          >
            {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            {isGenerating ? 'Generating...' : 'Magic Generate'}
          </button>
          <button 
            onClick={handleSave}
            className="flex items-center gap-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-4 py-2 rounded-md font-medium hover:bg-slate-800 dark:hover:bg-slate-100 transition-colors shadow-sm"
          >
            <Save className="w-4 h-4" />
            Save
          </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Main Editor Area */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Tabs */}
          <div className="flex items-center gap-6 px-8 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 pt-2 shrink-0 overflow-x-auto hide-scrollbar">
            {TABS.map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={cn(
                  "pb-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap",
                  activeTab === tab 
                    ? "border-blue-600 text-blue-600 dark:text-blue-400 dark:border-blue-400" 
                    : "border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white"
                )}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="flex-1 overflow-y-auto p-8">
            {activeTab === 'Overview' && (
              <div className="max-w-2xl space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Format</label>
                    <select 
                      value={item.contentType}
                      onChange={(e) => setItem({...item, contentType: e.target.value as any})}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-md outline-none"
                    >
                      <option value="Reel">Reel</option>
                      <option value="Post">Post</option>
                      <option value="Carousel">Carousel</option>
                      <option value="Article">Article</option>
                      <option value="Video">Video</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Publish Date</label>
                    <input 
                      type="datetime-local" 
                      value={item.publishAt ? item.publishAt.substring(0, 16) : ''}
                      onChange={(e) => setItem({...item, publishAt: new Date(e.target.value).toISOString()})}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-md outline-none"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Topic / Brief Description</label>
                  <textarea 
                    value={item.description || ''}
                    onChange={(e) => setItem({...item, description: e.target.value})}
                    placeholder="Brief description of this content (e.g. Current trend about AI)..."
                    className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-md outline-none min-h-[100px] resize-y"
                  />
                </div>
              </div>
            )}

            {activeTab === 'Script' && (
              <div className="max-w-3xl space-y-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-lg">Script Editor</h3>
                  <div className="flex items-center gap-4 text-sm font-medium">
                    <button 
                      onClick={() => generateWithAI('script')}
                      disabled={isGenerating}
                      className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-md hover:bg-indigo-100 transition-colors disabled:opacity-50"
                    >
                      {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                      Auto-write
                    </button>
                    <span className="text-slate-500">
                      {item.script?.split(' ').filter(Boolean).length || 0} words • ~{Math.ceil((item.script?.split(' ').filter(Boolean).length || 0) / 150)} min read
                    </span>
                  </div>
                </div>
                
                <Card className="shadow-sm">
                  <CardContent className="p-0">
                    <textarea 
                      value={item.script || ''}
                      onChange={(e) => setItem({...item, script: e.target.value})}
                      placeholder="Start writing your script here..."
                      className="w-full p-6 bg-transparent border-none outline-none min-h-[500px] resize-y text-lg leading-relaxed text-slate-700 dark:text-slate-300"
                    />
                  </CardContent>
                </Card>
              </div>
            )}

            {activeTab === 'Caption' && (
              <div className="max-w-2xl space-y-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-lg">Caption</h3>
                  <button 
                    onClick={() => generateWithAI('caption')}
                    disabled={isGenerating}
                    className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-md hover:bg-indigo-100 transition-colors disabled:opacity-50 text-sm font-medium"
                  >
                    {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                    Auto-write
                  </button>
                </div>
                <Card className="shadow-sm">
                  <CardContent className="p-0">
                    <textarea 
                      value={item.caption || ''}
                      onChange={(e) => setItem({...item, caption: e.target.value})}
                      placeholder="Write your caption..."
                      className="w-full p-6 bg-transparent border-none outline-none min-h-[300px] resize-y leading-relaxed text-slate-700 dark:text-slate-300"
                    />
                  </CardContent>
                </Card>
              </div>
            )}

            
            {activeTab === 'SEO' && (
              <div className="max-w-3xl space-y-6">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h3 className="font-semibold text-lg flex items-center gap-2"><Target className="w-5 h-5 text-indigo-500" /> SEO & Readability Audit</h3>
                    <p className="text-sm text-slate-500">Analyze your script or caption for keyword density and reading level.</p>
                  </div>
                  <button 
                    onClick={handleSeoAudit}
                    disabled={isAuditing || (!item.script && !item.caption)}
                    className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors disabled:opacity-50 text-sm font-medium shadow-sm"
                  >
                    {isAuditing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Activity className="w-4 h-4" />}
                    {isAuditing ? 'Analyzing...' : 'Run Deep AI Audit'}
                  </button>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Target Keywords (comma separated)</label>
                  <input 
                    type="text" 
                    value={seoKeywords}
                    onChange={(e) => setSeoKeywords(e.target.value)}
                    placeholder="e.g. social media marketing, content strategy"
                    className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-md outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="shadow-sm border-slate-200 dark:border-slate-800">
                    <CardContent className="p-4 flex items-center justify-between">
                       <div>
                         <h4 className="text-sm font-medium text-slate-500 uppercase tracking-wider">Real-time Readability</h4>
                         <p className="text-xs text-slate-400 mt-1">{realTimeSeo.words} words, {realTimeSeo.sentences} sentences</p>
                       </div>
                       <span className={cn(
                          "text-2xl font-bold px-3 py-1 rounded-md",
                          realTimeSeo.readability >= 80 ? "text-emerald-600 bg-emerald-50" :
                          realTimeSeo.readability >= 60 ? "text-amber-600 bg-amber-50" :
                          "text-red-600 bg-red-50"
                        )}>{realTimeSeo.readability}</span>
                    </CardContent>
                  </Card>
                  
                  <Card className="shadow-sm border-slate-200 dark:border-slate-800">
                    <CardContent className="p-4">
                       <h4 className="text-sm font-medium text-slate-500 uppercase tracking-wider mb-2">Real-time Keyword Density</h4>
                       {realTimeSeo.keywords.length === 0 ? (
                          <p className="text-sm text-slate-400 italic">No keywords specified</p>
                       ) : (
                          <div className="space-y-2">
                            {realTimeSeo.keywords.map((kw, i) => (
                              <div key={i} className="flex items-center justify-between text-sm">
                                <span className="font-medium text-slate-700 dark:text-slate-300">{kw.keyword}</span>
                                <div className="flex items-center gap-3">
                                  <span className="text-slate-500">{kw.count} uses</span>
                                  <span className={cn("px-2 py-0.5 rounded text-xs font-bold", kw.density >= 1 && kw.density <= 3 ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-600")}>
                                    {kw.density}%
                                  </span>
                                </div>
                              </div>
                            ))}
                          </div>
                       )}
                    </CardContent>
                  </Card>
                </div>

                {seoAnalysis && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                    <Card className="shadow-sm border-indigo-100 dark:border-indigo-900/50">
                      <CardContent className="p-6 space-y-4">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium text-slate-700 dark:text-slate-300">SEO Score</h4>
                          <span className={cn(
                            "text-xl font-bold px-3 py-1 rounded-full",
                            seoAnalysis.score >= 80 ? "bg-emerald-100 text-emerald-700" :
                            seoAnalysis.score >= 60 ? "bg-amber-100 text-amber-700" :
                            "bg-red-100 text-red-700"
                          )}>{seoAnalysis.score}/100</span>
                        </div>
                        <div>
                          <h5 className="text-xs font-bold text-slate-500 uppercase mb-1">Keyword Analysis</h5>
                          <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">{seoAnalysis.keywordAnalysis}</p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="shadow-sm border-blue-100 dark:border-blue-900/50">
                      <CardContent className="p-6 space-y-4">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium text-slate-700 dark:text-slate-300">Readability Score</h4>
                          <span className={cn(
                            "text-xl font-bold px-3 py-1 rounded-full",
                            seoAnalysis.readabilityScore >= 80 ? "bg-emerald-100 text-emerald-700" :
                            seoAnalysis.readabilityScore >= 60 ? "bg-amber-100 text-amber-700" :
                            "bg-red-100 text-red-700"
                          )}>{seoAnalysis.readabilityScore}/100</span>
                        </div>
                        <div>
                          <h5 className="text-xs font-bold text-slate-500 uppercase mb-1">Readability Feedback</h5>
                          <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">{seoAnalysis.readabilityFeedback}</p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="shadow-sm md:col-span-2">
                      <CardContent className="p-6">
                        <h4 className="font-medium text-slate-700 dark:text-slate-300 mb-4">Improvement Suggestions</h4>
                        <ul className="space-y-2">
                          {seoAnalysis.suggestions.map((suggestion, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-sm text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/50 p-3 rounded-lg border border-slate-100 dark:border-slate-800">
                              <Sparkles className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                              <span className="leading-relaxed">{suggestion}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  </div>
                )}
                {!seoAnalysis && !isAuditing && (
                   <div className="text-center py-12 bg-slate-50 dark:bg-slate-900 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 mt-6">
                      <Target className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                      <p className="text-slate-500 font-medium">Ready to analyze</p>
                      <p className="text-sm text-slate-400 mt-1 max-w-sm mx-auto">Enter target keywords above and click 'Run Audit' to get actionable SEO and readability insights.</p>
                   </div>
                )}
              </div>
            )}

{(activeTab === 'Brief' || activeTab === 'Assets' || activeTab === 'Review') && (
              <div className="flex flex-col items-center justify-center h-full text-slate-500 space-y-4">
                <LayoutGrid className="w-12 h-12 text-slate-300" />
                <p className="text-lg font-medium">{activeTab} panel placeholder</p>
                <p className="text-sm">This section would contain the structured forms and tools for {activeTab.toLowerCase()}.</p>
              </div>
            )}
          </div>
        </div>

        {/* Right Sidebar - Context & Collaboration */}
        <div className="w-80 bg-slate-50 dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 flex flex-col shrink-0">
          <div className="p-4 border-b border-slate-200 dark:border-slate-800 font-semibold">
            Status & Workflow
          </div>
          
          <div className="p-4 space-y-6 flex-1 overflow-y-auto">
            <ReadabilityRing text={(item.script || '') + ' ' + (item.caption || '') + ' ' + (item.description || '')} />
            
            {/* Approval Flow */}
            <div className="space-y-3">
              <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Approval</h4>
              
              <div className="flex gap-2">
                <button 
                  onClick={() => handleStatusChange('REVIEW')}
                  className={cn(
                    "flex-1 py-2 px-3 rounded-md text-sm font-medium transition-colors border",
                    item.status === 'REVIEW' 
                      ? "bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-500/10 dark:text-amber-400 dark:border-amber-500/20"
                      : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800"
                  )}
                >
                  Needs Review
                </button>
                <button 
                  onClick={() => handleStatusChange('APPROVED')}
                  className={cn(
                    "flex-1 py-2 px-3 rounded-md text-sm font-medium transition-colors border flex items-center justify-center gap-1.5",
                    item.status === 'APPROVED' || item.status === 'SCHEDULED' || item.status === 'PUBLISHED'
                      ? "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-400 dark:border-emerald-500/20"
                      : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800"
                  )}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Approve
                </button>
              </div>
            </div>

            {/* Comments Placeholder */}
            <div className="space-y-3 pt-6 border-t border-slate-200 dark:border-slate-800">
              <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center justify-between">
                Comments
                <span className="bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-1.5 py-0.5 rounded text-[10px]">0</span>
              </h4>
              <div className="text-center py-8 text-sm text-slate-500 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 border-dashed">
                No comments yet
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
