import { create } from 'zustand';
import { ContentItem, Idea, Campaign, User, ContentPillar, BrandContext } from '../types';
import { mockContent, mockIdeas, campaigns, users, pillars, currentUser } from '../lib/mockData';

interface AppState {
  brandContext: BrandContext;
  updateBrandContext: (updates: Partial<BrandContext>) => void;
  currentUser: User;
  users: User[];
  pillars: ContentPillar[];
  campaigns: Campaign[];
  content: ContentItem[];
  ideas: Idea[];
  
  // Actions
  addContent: (item: ContentItem) => void;
  updateContent: (id: string, updates: Partial<ContentItem>) => void;
  deleteContent: (id: string) => void;
  moveContent: (id: string, newStatus: any, newIndex: number) => void;
  
  addIdea: (idea: Idea) => void;
  updateIdea: (id: string, updates: Partial<Idea>) => void;
  deleteIdea: (id: string) => void;
}

export const useStore = create<AppState>((set) => ({
  brandContext: { brandName: '', targetAudience: '', brandVoice: '', competitors: '', additionalContext: '' },
  updateBrandContext: (updates) => set((state) => ({ brandContext: { ...state.brandContext, ...updates } })),
  currentUser,
  users,
  pillars,
  campaigns,
  content: mockContent,
  ideas: mockIdeas,
  
  addContent: (item) => set((state) => ({ content: [...state.content, item] })),
  updateContent: (id, updates) => set((state) => ({
    content: state.content.map(c => c.id === id ? { ...c, ...updates, updatedAt: new Date().toISOString() } : c)
  })),
  deleteContent: (id) => set((state) => ({
    content: state.content.filter(c => c.id !== id)
  })),
  moveContent: (id, newStatus, newIndex) => set((state) => {
    const itemIndex = state.content.findIndex(c => c.id === id);
    if (itemIndex === -1) return state;
    
    const item = { ...state.content[itemIndex], status: newStatus, updatedAt: new Date().toISOString() };
    
    const newContent = [...state.content];
    newContent.splice(itemIndex, 1);
    
    const targetColumnItems = newContent.filter(c => c.status === newStatus);
    
    if (newIndex >= targetColumnItems.length) {
      const lastItemInStatus = targetColumnItems[targetColumnItems.length - 1];
      if (lastItemInStatus) {
        const lastGlobalIndex = newContent.indexOf(lastItemInStatus);
        newContent.splice(lastGlobalIndex + 1, 0, item);
      } else {
        newContent.push(item);
      }
    } else {
      const itemAtNewIndex = targetColumnItems[newIndex];
      const insertGlobalIndex = newContent.indexOf(itemAtNewIndex);
      newContent.splice(insertGlobalIndex, 0, item);
    }
    
    return { content: newContent };
  }),
  
  addIdea: (idea) => set((state) => ({ ideas: [...state.ideas, idea] })),
  updateIdea: (id, updates) => set((state) => ({
    ideas: state.ideas.map(i => i.id === id ? { ...i, ...updates } : i)
  })),
  deleteIdea: (id) => set((state) => ({
    ideas: state.ideas.filter(i => i.id !== id)
  })),
}));
